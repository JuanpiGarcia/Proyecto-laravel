@extends('layouts.app')
@section('content')

    <h1>esta es la pagina de bienvenida</h1>


@endsection