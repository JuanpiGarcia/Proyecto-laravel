
<?php $__env->startSection('content'); ?>

	<h1>lista de los Productos</h1>
	<a class="btn btn-success mb-3" href="<?php echo e(route('products.create')); ?>"> Crear Producto</a>

	<?php if(empty($items)): ?>
		<div class="alert alert-warning">
			la lista esta vacia
		</div>
	<?php else: ?>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead class="thead-light">
					<tr>
						<th>Id</th>
						<th>Titulo</th>
						<th>Descripcion</th>
						<th>Precio</th>
						<th>Stock</th>
						<th>Estado</th>
						<th>Accion</th>
					</tr>
				</thead>
					<tbody>
						<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
							<tr>
								<td><?php echo e($product->id); ?></td>
								<td><?php echo e($product->title); ?></td>
								<td><?php echo e($product->description); ?></td>
								<td><?php echo e($product->pricee); ?></td>
								<td><?php echo e($product->stock); ?></td>
								<td><?php echo e($product->status); ?></td>
								<td>
									<a class="btn btn-link" href="<?php echo e(route('products.show',['product'=>$product->id])); ?>"> Mostrar </a>
									<a class="btn btn-link" href="<?php echo e(route('products.edit',['product'=>$product->id] )); ?>"> editar </a>

									<form method="POST" class="d-inline" action="<?php echo e(route('products.delete',['product'=>$product->id])); ?>">
										<?php echo csrf_field(); ?>
										<?php echo method_field('DELETE'); ?>
										<button type="submit" class="btn btn-link">Eliminar</button>
										
									</form>
								</td> 
								
							</tr>			
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
			</table>
		</div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-desde-cero\resources\views/products/index.blade.php ENDPATH**/ ?>