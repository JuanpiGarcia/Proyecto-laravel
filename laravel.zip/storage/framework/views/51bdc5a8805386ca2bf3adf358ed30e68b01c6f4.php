<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>CervezasNacho</title>
</head>
<body>

	<?php if(session()->has('exito')): ?>
		<div class="alert alert-success">
			<?php echo e(session()->get('exito')); ?>

		</div>
	<?php endif; ?>

	
	<?php if(isset($errors) && $errors->any()): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($element); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>

	<?php endif; ?>

	<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-desde-cero\resources\views/layouts/master.blade.php ENDPATH**/ ?>