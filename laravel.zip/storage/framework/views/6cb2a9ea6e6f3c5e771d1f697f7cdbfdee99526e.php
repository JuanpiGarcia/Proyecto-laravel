
<?php $__env->startSection('content'); ?>

	<h1>edicion del formulario</h1>
	
	<form method="POST" action="<?php echo e(route('products.update',['product' =>$items->id])); ?>">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		
		
		
		<div class="form-row">
			<label >Titulo</label>
			<input class="form-control" type="text" name="title" value="<?php echo e(old('title') ?? $items->title); ?>" >
		</div>
		<div class="form-row">
			<label >Descripcion</label>
			<input class="form-control" type="text" name="description" value="<?php echo e(old('description') ?? $items->description); ?>" >
		</div>
		<div class="form-row">
			<label >Precio</label>
			<input class="form-control" type="number" min="1" name="pricee" value="<?php echo e(old('pricee') ?? $items->pricee); ?>" >
		</div>
		<div class="form-row">
			<label >Stock</label>
			<input class="form-control" type="number" min="0" name="stock" value="<?php echo e(old('stock') ?? $items->stock); ?>" >
		</div>
		<div class="form-row">
			<label >Status</label>
			<select class="custom-select" name="status"  >
				
				<option <?php echo e(old('status') == 'disponible' ? 'selected' : 
						($items->status == 'disponible' ? 'selected' : '')); ?>

						 value="disponible">Disponible</option>

				<option <?php echo e(old('status') == 'nodisponible' ? 'selected' : 
						($items->status == 'nodisponible' ? 'selected' : '')); ?> 
						value="nodisponible">No Disponible</option>
			</select>
		</div>
		<div class="form-row mt-3" >
			<button type="submit" class="btn btn-primary btn-lg"> Actualizar</button>
		</div>


	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-desde-cero\resources\views/products/edit.blade.php ENDPATH**/ ?>