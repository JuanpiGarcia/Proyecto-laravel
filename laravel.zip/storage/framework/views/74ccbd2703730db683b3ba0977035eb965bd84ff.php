
<?php $__env->startSection('content'); ?>

	<h1>creacion del formulario</h1>
	
	<form method="POST" action="<?php echo e(route('products.store')); ?>">
		<?php echo csrf_field(); ?>
		
		<div class="form-row">
			<label >Titulo</label>
			<input class="form-control" type="text" name="title" value="<?php echo e(old('title')); ?>">
		</div>
		<div class="form-row">
			<label >Descripcion</label>
			<input class="form-control" type="text" name="description" value="<?php echo e(old('description')); ?>">
		</div>
		<div class="form-row">
			<label >Precio</label>
			<input class="form-control" type="number" min="1" name="pricee" value="<?php echo e(old('pricee')); ?>">
		</div>
		<div class="form-row">
			<label >Stock</label>
			<input class="form-control" type="text" min="0" name="stock" value="<?php echo e(old('stock')); ?>">
		</div>
		<div class="form-row">
			<label >Estado</label>
			<select class="custom-select" name="status" >
				<option value="" selected>Selecciona</option>
				<option <?php echo e(old('status') == 'disponible' ? 'selected' : ''); ?> value="disponible">Disponible</option>
				<option <?php echo e(old('status') == 'nodisponible' ? 'selected' : ''); ?> value="nodisponible">No Disponible</option>
			</select>
		</div>
		<div class="form-row mt-3">
			<button type="submit" class="btn btn-primary btn-lg"> Guardar</button>
		</div>


	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-desde-cero\resources\views/products/create.blade.php ENDPATH**/ ?>