
<?php $__env->startSection('content'); ?>

	<h1>id : <?php echo e($items->id); ?></h1>
	<h1><?php echo e($items->title); ?></h1>
	<h1><?php echo e($items->description); ?></h1>
	<h1><?php echo e($items->price); ?></h1>
	<h1><?php echo e($items->status); ?></h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-desde-cero\resources\views/products/show.blade.php ENDPATH**/ ?>